package com.core.TecHeart.enums;

public enum DataSourceType {
    MANUAL, DEVICE, SYSTEM
}
