package com.core.TecHeart.enums;

public enum HealthMetricType {
    HRV, BP, SpO2
}